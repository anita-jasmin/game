class Game{
    constructor(){

    }
    //story for alice and her sister
    Scene1(){

      if(gameStates===1){
        createCanvas(displayWidth,400);
        
        image(tree,150,80,190,200);
        
       //ground=createSprite(displayWidth/2,350,displayWidth,150);
         
         
      }
    }

    
    //platform game chase the rabbit
    Scene2(){
    
        if(gameStates===2){

            image(meadow,0,0,displayWidth,600);
            //sound2=loadSound("sound/Town1.mp3");
            //sound2.play();
            //Collision Class
            //collision=new Collision();
            //collision.PlayerCollide();
            //gravity for player
           // player.velocityY+=0.6;

            
           
            
            

                
             

               
             
        }
    }
      //fall into the rabbit hole
      //Level2(){
        //drawSprites();
          //if (gameStates===2){
            //createCanvas(800,displayHeight);
            //background("black");
            //player=createSprite(400,displayHeight/10,100,100);
             //if(keyDown("a")){
              //  player.x-=10;
                //}
              //else if(keyDown("d")){
              //player.x+=10;
                //}
                   
                 //}
               //}
               //4 doors
              // level3(){}
               //duchess
               //Door1(){}
               //Mad Hatter
               //Door2(){}
               //Queen of Hearts
               //Door3(){}
               //???
               //Door4(){}
               //bad ending
               //Ending1(){}
               //good ending
               //Ending2(){}
               
}