
var gameStates=1;
//player
var player,playerstand,playerwalk;
//emotions
var heart,surprised,question,angry;
//emotions images
var heartImg,surprisedImg,questionImg,angryImg;
//scene1
var ground1,tree;
//scene1 images
var treeImg,bunnyImg,ground1Img;
//scene2
var block,block1,block2,block3,block4,block5,block6;
var door1;
var movingplatform;
//scene2 images
var meadow,platform;
//scene3
var wine,drink,cake,liquid,glass;
//scene3 images
var wineImg,drinkImg,cakeImg,liquidImg,glassImg;
//scene4
var key1;
//scene4 images
var keyImg,bg4Img,stoneImg,stoneImg1,stoneImg2,stoneImg3;
//scene5
var cat;
var door1,door2;
//scene5 images
var forest,catsleep,doorImg;
//texts
var a="The Duchess";
var e="The Mad Hatter and The March Hare";
var c="The Queen of Hearts";
var d="The Knave of Hearts";
//scene6
var duchessbg,duchess,cook,cauldron;

 



function preload(){

  playerstand=loadAnimation("playerimg/playerwalk2.png");
  playerwalk=loadAnimation("playerimg/playerwalk1.png",
  "playerimg/playerwalk2.png","playerimg/playerwalk3.png")
   sisterstand=loadAnimation("sister/sisterwalk2.png");
   sisterwalk=loadAnimation("sister/sisterwalk1.png",
   "sister/sisterwalk2.png","sister/sisterwalk3.png")
  
  //bg loaded
  meadow=loadImage("bg/grassy_plains.jpg");
  forest=loadImage("bg/wonderland2.png");
  bg4Img=loadImage("bg/scene4bg.png");
  duchessbgImg=loadImage("bg/duchessbg.png");
  
   
  //emotions images
  heartImg=loadAnimation("emotions/heart1.png","emotions/heart2.png",
  "emotions/heart3.png","emotions/heart4.png","emotions/heart5.png"
  ,"emotions/heart6.png","emotions/heart7.png","emotions/heart8.png");
  surprisedImg=loadAnimation("emotions/!1.png","emotions/!2.png",
  "emotions/!3.png","emotions/!4.png","emotions/!5.png"
  ,"emotions/!6.png","emotions/!7.png","emotions/!8.png");
  questionImg=loadAnimation("emotions/question1.png","emotions/question2.png",
  "emotions/question3.png","emotions/question4.png","emotions/question5.png"
  ,"emotions/question6.png","emotions/question7.png","emotions/question8.png");
  angryImg=loadAnimation("emotions/angry1.png","emotions/angry2.png",
  "emotions/angry3.png","emotions/angry4.png","emotions/angry5.png"
  ,"emotions/angry6.png","emotions/angry7.png");

  //scene1 images loaded
  treeImg=loadImage("accessories/tree.png");
  bunnyImg=loadAnimation("bunny/bunny1.png",
  "bunny/bunny2.png","bunny/bunny3.png")
  ground1Img=loadImage("accessories/ground1.png");
  
  
  //scene2 images
  platform=loadImage("accessories/platform.png");
  
  //scene3 images
  wineImg=loadAnimation("accessories/wine1.png",
  "accessories/wine2.png","accessories/wine3.png","accessories/wine4.png",
  "accessories/wine5.png","accessories/wine6.png");
  liquidImg=loadAnimation("accessories/red1.png","accessories/red2.png",
  "accessories/red3.png","accessories/red4.png","accessories/red5.png",
  "accessories/red6.png");
  glassImg=loadAnimation("accessories/glass1.png","accessories/glass2.png",
  "accessories/glass3.png","accessories/glass4.png","accessories/glass5.png",
  "accessories/glass6.png","accessories/glass7.png","accessories/glass8.png");
  
  //scene 4 images
  keyImg=loadImage("accessories/key.png");

  ground2Img=loadImage("accessories/ground2.png");
  stoneImg=loadImage("accessories/stone.png");
  stoneImg1=loadImage("accessories/stone1.png");
  stoneImg2=loadImage("accessories/stone2.png");
  stoneImg3=loadImage("accessories/stone3.png");
  stoneImg4=loadImage("accessories/stone4.png");

  gateImg=loadAnimation("accessories/gate1.png","accessories/gate2.png",
  "accessories/gate3.png","accessories/gate4.png",
  );
  gateclosed=loadAnimation("accessories/gate1.png");
 
  //scene5 images
  catsleep=loadAnimation("cat/catback.png");
  catawake=loadAnimation("cat/catback.png",
  "cat/catright.png","cat/catfront.png","cat/catfront1.png");
  catstand=loadAnimation("cat/catfront1.png");
  doorImg=loadImage("accessories/door1.png");
  signImg=loadImage("accessories/sign1.png");

  //scene6 images
  duchessImg=loadImage("scene6/duchess.png");
  cookImg=loadImage("scene6/cook.png");
  cauldronImg=loadImage("scene6/cauldron.png");
}

function setup() {

  createCanvas(displayWidth, 400);
   
  
 if(gameStates===1){
  //scene1
  ground1=createSprite(displayWidth/2,350,displayWidth,150);
  ground1.addImage("ground1",ground1Img)
  ground1.scale=1.85;

  tree=createSprite(displayWidth/12.8,185,190,200)
  tree.addImage("tree",treeImg);
  tree.scale=2.9;
  
  sister=createSprite(displayWidth/10,230,10,10);
  sister.addAnimation("sisterstand",sisterstand);
  sister.mirrorX(-1);
  sister.addAnimation("sisterwalk",sisterwalk);
 }
  
  


   
 if(gameStates===2){ 
    //scene2
    block=createSprite(displayWidth/38,250,100,5);
    block.addImage("platform0",platform);
    block.scale=0.7;
             
    block1=createSprite(displayWidth/7,280,100,5);
    block1.addImage("platform0",platform);         
    block1.scale=0.7
         
    block2=createSprite(displayWidth/4,210,100,5);         
    block2.addImage("platform0",platform);
    block2.scale=0.7
             
    block3=createSprite(displayWidth/3,130,100,5);         
    block3.addImage("platform0",platform);         
    block3.scale=0.7
             
    block4=createSprite(displayWidth/1.5,210,100,5);         
    block4.addImage("platform0",platform);
    block4.scale=0.7
             
    block5=createSprite(1000,260,100,5);         
    block5.addImage("platform0",platform);         
    block5.scale=0.7
             
    block6=createSprite(displayWidth/2,160,100,5);
    block6.addImage("platform0",platform); 
    block6.scale=0.7
             
    movingplatform=createSprite(displayWidth/2+250,350,100,5);         
    movingplatform.addImage("platform",platform);       
    movingplatform.scale=0.7;
 }

 if(gameStates===4){
    //scene4
    key1=createSprite(displayWidth/2,50,20,20);
    key1.addImage(keyImg);

    gate=createSprite(displayWidth/1.025,350,20,20);
    gate.addAnimation("close",gateclosed);
    gate.scale=0.7;
    gate1=createSprite(displayWidth/38,60,20,20);
    gate1.addAnimation("close",gateclosed);
    gate1.scale=0.7;
    gate2=createSprite(displayWidth/1.025,60,20,20);
    gate2.addAnimation("close",gateclosed);
    gate2.scale=0.7;

    b=createSprite(displayWidth/2,390,displayWidth,20);
    b.addImage(ground2Img)
    b1=createSprite(displayWidth/38,310,100,20);
    b1.addImage(stoneImg);
    b2=createSprite(displayWidth/10,330,20,150);
    b2.addImage(stoneImg3);
    b3=createSprite(displayWidth/38,100,100,20);
    b3.addImage(stoneImg);
    b4=createSprite(displayWidth/8,180,20,20);
    b4.addImage(stoneImg2);
    b5=createSprite(displayWidth/6.4,355,50,50);
    b5.addImage(stoneImg1);
    b6=createSprite(displayWidth/5,120,20,250);
    b6.addImage(stoneImg4);
    b7=createSprite(displayWidth/3,150,100,20);
    b7.addImage(stoneImg);
    b8=createSprite(displayWidth/1.5,150,100,20);
    b8.addImage(stoneImg);
    b9=createSprite(displayWidth/2,240,100,20);
    b9.addImage(stoneImg);
    b10=createSprite(displayWidth/2.5,270,50,50);
    b10.addImage(stoneImg1);
    b11=createSprite(displayWidth/1.7,270,50,50);
    b11.addImage(stoneImg1);
    b12=createSprite(displayWidth/1.15,330,20,150);
    b12.addImage(stoneImg3);
    b13=createSprite(displayWidth/1.025,310,100,20);
    b13.addImage(stoneImg);
    b14=createSprite(displayWidth/1.025,100,100,20);
    b14.addImage(stoneImg);
    b15=createSprite(displayWidth/1.1,180,20,20);
    b15.addImage(stoneImg2);
    b16=createSprite(displayWidth/1.25,120,20,250);
    b16.addImage(stoneImg4);        
 }
 if(gameStates===5){
    
    //scene5
    cat=createSprite(displayWidth/2,350,10,10);
    cat.addAnimation("sleep",catsleep);

    door1=createSprite(displayWidth/6,330,10,10);
    door1.addImage("door",doorImg);

    door2=createSprite(displayWidth/2.8,330,10,10);
    door2.addImage("door",doorImg);
 
    door3=createSprite(displayWidth/1.6,330,10,10);
    door3.addImage("door",doorImg);    

    door4=createSprite(displayWidth/1.2,330,10,10);
    door4.addImage("door",doorImg); 

    sign1=createSprite(displayWidth/4.8,340,10,10);
    sign1.addImage("sign",signImg);
 
    sign2=createSprite(displayWidth/2.5,340,10,10);
    sign2.addImage("sign",signImg);

    sign3=createSprite(displayWidth/1.72,340,10,10);
    sign3.addImage("sign",signImg);

    sign4=createSprite(displayWidth/1.27,340,10,10);
    sign4.addImage("sign",signImg);
 }        
    //scene6 characters
    //duchess=createSprite(displayWidth/2,370,20,20);
    //duchess.addImage(duchessImg);
    //cook=createSprite(displayWidth/1.165,370,20,20);          
    //cook.addImage(cookImg);
    //cauldron=createSprite(displayWidth/1.115,370,20,20);
    //cauldron.addImage(cauldronImg);
    
                

   
     //player sprite           
     player=createSprite(20,230,20,20);
     player.addAnimation("playerstand",playerstand);
     player.addAnimation("playerwalk",playerwalk);
  
}

function draw() {
  //console.log("gameStates"+gameStates);
 //console.log("playerX"+player.x)
 //console.log("playerY"+player.y);
  
  //backgrounds
  if(gameStates===1||gameStates===2)
  {
    background(meadow);
  }
  else if(gameStates===4){
    background(bg4Img);
    
  }
  else if (gameStates===5){
    background(forest);
    player.y=350;
    
  }
  else if(gameStates===6){
    background(duchessbgImg);
    player.y=370;
  }
  else if(gameStates===7){
    background("black");
    player.y=200;
    player.x=displayWidth/2;
  }
  
  NextLevel();
  //Visibility();
  drawSprites();
  charMove();
  PlayerCollide();
  MovingPlatform();
  
  //key collect
  if(gameStates===4&&player.overlap(key1))
  {
    key1.visible=false;
  }
  
  //scene5 texts
  if(gameStates===5){

    if(player.overlap(sign1))
  {
    textSize(65)
    text(a,displayWidth/2.5,200)
  }
  
  else if(player.overlap(sign2))
  {
    textSize(65)
    text(e,displayWidth/2.5,200)
  }
  
  else if(player.overlap(sign3))
  {
    textSize(65)
    text(c,displayWidth/2.5,200)
  }
  
  else if(player.overlap(sign4))
  {
    textSize(65)
    text(d,displayWidth/2.5,200)
  }
  }
  
    
 
    

  
  
}

function charMove(){

  if(gameStates===2||gameStates===4)
  {
   player.velocityY+=0.5;
   
    if(keyIsDown(87))
    {
      player.y-=10;
    }
    else if(keyIsDown(83)){
      player.y+=10;
    }

  }
  
    if (keyIsDown(68))
    {
    
    player.changeAnimation("playerwalk",playerwalk);
    player.mirrorX(1);
    player.x+=10;

  }

   else if(keyIsDown(65)){
    player.changeAnimation("playerwalk",playerwalk);
    player.mirrorX(-1);
    player.x-=10;
  }
  else
  player.changeAnimation("playerstand",playerstand);
}

function PlayerCollide(){
  
  if(gameStates===2)
  {
 //console.log("hello");
    player.collide(block);
    player.collide(block1);
    player.collide(block2);
    player.collide(block3);
    player.collide(block4);
    player.collide(block5);
    player.collide(block6);
    player.collide(movingplatform);  
  
  }
  else if(gameStates===4){
    player.collide(b);
    player.collide(b1);
    player.collide(b2);
    player.collide(b3);
    player.collide(b4);
    
    if(player.y>=b5.y&&player.y<=b5.y){
      player.collide(b5);
    }
    else{
      player.displace(b5);
    }
    

  
    
    player.collide(b6);
    player.collide(b7);
    player.collide(b8);
    player.collide(b9);
    player.collide(b10);
    player.collide(b11);
    player.collide(b12);
    player.collide(b13);
    player.collide(b14);
    player.collide(b15);
    player.collide(b16);
  }

  
}

function MovingPlatform()
{
if(gameStates===2){

  movingplatform.velocityX+=0.2;
  if(movingplatform.x>=displayWidth-250){
    movingplatform.velocityX-=1;
  }
  else if(movingplatform.x>=displayWidth/2+250){
    movingplatform.velocityX+=0.2;
  }
  
  if(player.collide(movingplatform)){
    player.x=movingplatform.x;
    
  }
  
}
  

}

function Visibility()
{
  if(gameStates===1)
  {
    tree.visible=true;
    ground1.visible=true;
    sister.visible=true;
  }

   if(gameStates===2)
  {

  block.visible=true;
  block1.visible=false;
  block2.visible=false;
  block3.visible=false;
  block4.visible=false;
  block5.visible=false;
  block6.visible=false;
  movingplatform.visible=false;

  }
  if(gameStates!==4){
    b.visible=false;
    b1.visible=false;
    b2.visible=false;
    b3.visible=false;
    b4.visible=false;
    b5.visible=false;
    b6.visible=false;
    b7.visible=false;
    b8.visible=false;
    b9.visible=false;
    b10.visible=false;
    b11.visible=false;
    b12.visible=false;
    b13.visible=false;
    b14.visible=false;
    b15.visible=false;
    b16.visible=false;
    gate.visible=false;
    gate1.visible=false;
    gate2.visible=false;
    key1.visible=false;
  }
  if(gameStates!==5){
    cat.visible=false;
    door1.visible=false;
    door2.visible=false;
    door3.visible=false;
    door4.visible=false;
    sign1.visible=false;
    sign2.visible=false;
    sign3.visible=false;
    sign4.visible=false;
  }
}
function createPepper(){
  var p=createSprite(x,y,10,10);
  p.setSpeed(2.5-(type/2),random(360))
  a.rotationSpeed=0.5;

}

function NextLevel(){
  if(gameStates===1&&player.x>displayWidth-10){
    console.log("hi")
    gameStates=2;
    
  }
  else if(gameStates===4&&keyDown("ENTER")&&key1.visible===false&&
  player.x>=displayWidth/1.043&&player.x<=displayWidth&&player.y<=350){
    gameStates=5;
  }
  else if(gameStates===5&&keyDown("UP_ARROW"))
  {
    gameStates=6;
  }
}

 


